(function() {
    'use strict';
    let clock = document.createElement("div")
    let hourSpan = document.createElement("span");
    let minuteSpan = document.createElement("span");
    let secondSpan = document.createElement("span");
    let hSpan = document.createElement("span");
    let mSpan = document.createElement("span");
    let sSpan = document.createElement("span");
    clock.appendChild(hourSpan);
    clock.appendChild(hSpan);
    clock.appendChild(minuteSpan);
    clock.appendChild(mSpan);
    clock.appendChild(secondSpan);
    clock.appendChild(sSpan);
    // 样式
    clock.setAttribute("style", "position: absolute;right: 30px;top: 30px;z-index:999; width: 200px; height: 50px; font-size: 20px; color:purple; border-radius: 10px;background:rgba(120,24,5,0.5);");
    hourSpan.setAttribute("style", "display: inline-block;width: 30px;height: 20px;color: #fff;font-size: 20px;text-align: center;line-height: 20px;color:lightblue; margin: 10px");
    minuteSpan.setAttribute("style", "display: inline-block;width: 30px;height: 20px;color: #fff;font-size: 20px;text-align: center;line-height: 20px;color:lightblue;margin: 10px");
    secondSpan.setAttribute("style", "display: inline-block;width: 30px;height: 20px;color: #fff;font-size: 20px;text-align: center;line-height: 20px;color:lightblue;margin: 10px");
    hourSpan.innerHTML = "01";
    minuteSpan.innerHTML = "03";
    secondSpan.innerHTML = "10";
    hSpan.innerHTML = "h"
    mSpan.innerHTML = "m"
    sSpan.innerHTML = "s"
    let res = setInterval(() => {
      // 注意 加号，进行隐式数据转换，字符串转为数字，否则会出现不断补零的效果
      let h = +hourSpan.innerHTML;
      let m = +minuteSpan.innerHTML;
      let s = +secondSpan.innerHTML;
      s--;
      if(s < 0){
        s = 59;
        m--;
      }
      if(m < 0){
        m = 59;
        h--;
    }
    // 补零
    h = h < 10 ? '0'+h : h;
    m = m < 10 ? '0'+m : m;
    s = s < 10 ? '0'+s : s;
    hourSpan.innerHTML = h;
    minuteSpan.innerHTML = m;
    secondSpan.innerHTML = s;
    if(s == 0 && m == 0 && h == 0){
      // 如果时间都等于零，提醒
      alert('计时器时间到');
      hourSpan.innerHTML = 24;
      minuteSpan.innerHTML = 0;
      secondSpan.innerHTML = 0;
    }
  }, 1000);
  document.body.insertBefore(clock, document.body.firstElementChild);
  window.onkeydown = function () {
      event.preventDefault();
      // ctrl + z
      if(event.ctrlKey && event.keyCode === 90){
          clock.style.display = "none";
      }
      // ctrl + x
      if(event.ctrlKey && event.keyCode === 88){
          clock.style.display = "";
      }
      // ctrl + c
      if(event.ctrlKey && event.keyCode === 67){
          let input = prompt("请输入时间(hh-mm-ss)");
          let time = input.split("-");
          hourSpan.innerHTML = time[0];
          minuteSpan.innerHTML = time[1];
          secondSpan.innerHTML = time[2];
      }
  }
})();