// 确保在页面加载完成后执行
window.addEventListener('load', function() {
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'toggleDarkMode') {
      toggleDarkMode();
      sendResponse({status: 'dark mode toggled'});
      return true; // 表示异步响应
    }
  });

  function toggleDarkMode() {
    const darkModeEnabled = document.body.classList.toggle('dark-mode');
    const message = darkModeEnabled ? 'Dark mode enabled.' : 'Dark mode disabled.';
    console.log(message);
    injectDarkModeCSS();
  }

  function injectDarkModeCSS() {
    const darkModeCSS = document.createElement('style');
    darkModeCSS.type = 'text/css';
    darkModeCSS.innerHTML = `
      .dark-mode {
        background-color: #333;
        color: #fff;
      }
    `;
    if (!document.querySelector('style[data-dark-mode]')) {
      (document.head || document.documentElement).appendChild(darkModeCSS);
      darkModeCSS.setAttribute('data-dark-mode', 'true');
    }
  }
});