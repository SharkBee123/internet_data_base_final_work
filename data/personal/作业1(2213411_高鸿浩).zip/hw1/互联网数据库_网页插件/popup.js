// 确保页面加载完成后再绑定事件监听器
window.addEventListener('load', function() {
    document.getElementById('toggleDarkMode').addEventListener('click', function() {
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {action: 'toggleDarkMode'}, function(response) {
          if (chrome.runtime.lastError) {
            console.error(chrome.runtime.lastError.message);
          } else if (response) {
            console.log(response.status); // 这应该在控制台打印 "dark mode toggled"
          } else {
            console.log('No response from content script');
          }
        });
      });
    });
  });